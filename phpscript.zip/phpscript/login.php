
 <html>
<head>
<center>
  <title>välkommen!</title>
</head>

<body>
  <h1>Hej!</h1>
 
</body>
</center>
</html> 