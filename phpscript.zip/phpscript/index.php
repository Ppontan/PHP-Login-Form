
<html>
<head>
    <title>LOGIN</title>
	   <link rel = "stylesheet" type = "text/css" href = "style.css">   
</head>
<center>
<body>

     <form action="login.php" method="post">

        <h2>Inloggning</h2>

        <?php if (isset($_GET['error'])) { ?>

            <p class="error"><?php echo $_GET['error']; ?></p>

        <?php } ?>

        <label>Användarnamn</label>

        <input type="text" name="uname" placeholder="Användarnamn"><br>

        <label>Lösenord</label>

        <input type="password" name="password" placeholder="lösenord"><br> 

        <button type="submit">Logga in</button>

     </form>
	 
 <?php
    include 'connection.php';
    $conn = OpenCon();
    echo "Ansluten till server";
    CloseCon($conn);
    ?>
	</center>
</body>
</html>



